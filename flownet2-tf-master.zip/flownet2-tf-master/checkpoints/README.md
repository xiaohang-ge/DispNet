This directory contains TensorFlow checkpoints for each model. The weights were converted from the original FlowNet2 Caffe models.

Run `sh download.sh` to download the weights.

or

Follow the instructions in scripts/caffe/README.md to convert the Caffe weights to TensorFlow checkpoints manually.
