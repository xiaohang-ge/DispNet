#!/bin/sh

wget https://s3.us-east-2.amazonaws.com/flownetdata/weights.tar.gz
tar -xzf weights.tar.gz
